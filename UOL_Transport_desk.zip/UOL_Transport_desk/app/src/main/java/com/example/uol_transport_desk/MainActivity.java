package com.example.uol_transport_desk;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public static final String EXTRA_NAME = "student_name";

    private TextInputLayout tilName;
    private EditText etName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: Activity started");
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tilName = findViewById(R.id.tilName);
        etName = findViewById(R.id.etName);
        Button btnPage = findViewById(R.id.btnPage);
        Button btnCallOffice = findViewById(R.id.btnCallOffice);
        Button btnBusStop = findViewById(R.id.btnBusStop);
        Button btnReport = findViewById(R.id.btnReport);

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tilName.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnPage.setOnClickListener(v -> {
            Log.d(TAG, "User requested University Page");
            openIntent(v, new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uol.edu.pk")));
        });

        btnCallOffice.setOnClickListener(v -> {
            Log.d(TAG, "User requested Call Transport Office");
            openIntent(v, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:04298765432")));
        });

        btnBusStop.setOnClickListener(v -> {
            Log.d(TAG, "User requested Bus Stop location");
            openIntent(v, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=Thokar+Niaz+Baig,+Lahore")));
        });

        btnReport.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) {
                Log.w(TAG, "Report failed: Name is empty");
                tilName.setError(getString(R.string.error_name_empty));
                return;
            }
            Log.d(TAG, "Navigating to ProblemActivity for user: " + name);
            Intent intent = new Intent(MainActivity.this, ProblemActivity.class);
            intent.putExtra(EXTRA_NAME, name);
            startActivity(intent);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Activity visible");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Activity hidden");
    }

    public static void openIntent(View view, Intent intent) {
        try {
            view.getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "No activity found to handle action: " + intent.getAction(), e);
            Snackbar.make(view, R.string.error_no_app, Snackbar.LENGTH_LONG).show();
        }
    }
}
