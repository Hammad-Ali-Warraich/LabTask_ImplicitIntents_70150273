package com.example.uol_transport_desk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputLayout;

public class ProblemActivity extends AppCompatActivity {

    private static final String TAG = "ProblemActivity";
    
    private TextInputLayout tilDriverPhone, tilEmail;
    private EditText etDriverPhone, etEmail;
    private String studentName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: Activity started");
        setContentView(R.layout.activity_problem);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        studentName = getIntent().getStringExtra(MainActivity.EXTRA_NAME);
        if (studentName == null || studentName.isEmpty()) {
            studentName = "Student";
        }
        Log.d(TAG, "Received name for report: " + studentName);

        TextView tvGreeting = findViewById(R.id.tvGreeting);
        tvGreeting.setText(getString(R.string.greeting_format, studentName));

        tilDriverPhone = findViewById(R.id.tilDriverPhone);
        tilEmail = findViewById(R.id.tilEmail);
        etDriverPhone = findViewById(R.id.etDriverPhone);
        etEmail = findViewById(R.id.etEmail);
        Button btnCallDriver = findViewById(R.id.btnCallDriver);
        Button btnSendEmail = findViewById(R.id.btnSendEmail);

        setupTextWatcher(etDriverPhone, tilDriverPhone);
        setupTextWatcher(etEmail, tilEmail);

        btnCallDriver.setOnClickListener(v -> {
            String number = etDriverPhone.getText().toString().trim();
            Log.d(TAG, "User requested Call Driver: " + number);
            if (!number.matches("03\\d{9}")) {
                Log.w(TAG, "Call failed: Invalid phone number format");
                tilDriverPhone.setError(getString(R.string.error_invalid_phone));
                return;
            }
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
            MainActivity.openIntent(v, intent);
        });

        btnSendEmail.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String driverPhone = etDriverPhone.getText().toString().trim();
            
            Log.d(TAG, "User requested Send Email to: " + email);
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Log.w(TAG, "Email failed: Invalid address format");
                tilEmail.setError(getString(R.string.error_invalid_email));
                return;
            }

            // Create a rich email intent
            String subject = getString(R.string.email_subject, studentName);
            String body = getString(R.string.email_body_template, studentName, 
                    driverPhone.isEmpty() ? "Not provided" : driverPhone);

            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + email));
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);
            intent.putExtra(Intent.EXTRA_TEXT, body);
            
            MainActivity.openIntent(v, intent);
        });
    }

    private void setupTextWatcher(EditText editText, TextInputLayout inputLayout) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                inputLayout.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Activity visible");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Activity hidden");
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Log.d(TAG, "Toolbar Back button clicked");
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
